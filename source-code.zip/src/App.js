import './App.css';
import { OnBoarding } from './pages';

function App() {
  return (
    <div className="App">
      <OnBoarding />
    </div>
  );
}

export default App;
