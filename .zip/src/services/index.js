export { getQuote } from "./quote";
export { getWeather } from "./weather";
